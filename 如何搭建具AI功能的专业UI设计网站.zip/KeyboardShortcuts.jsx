import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Keyboard, 
  X, 
  Command, 
  MousePointer,
  Square,
  Circle,
  Type,
  Copy,
  Trash2,
  Undo,
  Redo,
  Save,
  ZoomIn,
  ZoomOut
} from 'lucide-react';

const KeyboardShortcuts = ({ isOpen, onClose }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const shortcuts = [
    {
      category: '基本操作',
      items: [
        { key: 'Ctrl + Z', action: '撤销', icon: Undo },
        { key: 'Ctrl + Y', action: '重做', icon: Redo },
        { key: 'Ctrl + S', action: '保存', icon: Save },
        { key: 'Ctrl + C', action: '复制', icon: Copy },
        { key: 'Delete', action: '删除选中元素', icon: Trash2 },
        { key: 'Escape', action: '取消选择', icon: X },
      ]
    },
    {
      category: '工具切换',
      items: [
        { key: 'V', action: '选择工具', icon: MousePointer },
        { key: 'R', action: '矩形工具', icon: Square },
        { key: 'O', action: '圆形工具', icon: Circle },
        { key: 'T', action: '文本工具', icon: Type },
        { key: 'Space', action: '临时切换到移动工具', icon: MousePointer },
      ]
    },
    {
      category: '视图控制',
      items: [
        { key: 'Ctrl + +', action: '放大', icon: ZoomIn },
        { key: 'Ctrl + -', action: '缩小', icon: ZoomOut },
        { key: 'Ctrl + 0', action: '适应画布', icon: ZoomIn },
        { key: 'Ctrl + 1', action: '100% 缩放', icon: ZoomIn },
        { key: 'Ctrl + G', action: '显示/隐藏网格', icon: Square },
      ]
    },
    {
      category: '元素操作',
      items: [
        { key: 'Ctrl + D', action: '复制选中元素', icon: Copy },
        { key: 'Ctrl + A', action: '全选', icon: MousePointer },
        { key: 'Ctrl + Shift + A', action: '取消全选', icon: X },
        { key: '↑↓←→', action: '移动选中元素', icon: MousePointer },
        { key: 'Shift + ↑↓←→', action: '精确移动 (10px)', icon: MousePointer },
      ]
    },
    {
      category: 'AI功能',
      items: [
        { key: 'Ctrl + Shift + S', action: 'AI样式推荐', icon: Command },
        { key: 'Ctrl + Shift + C', action: 'AI配色建议', icon: Command },
        { key: 'Ctrl + Shift + L', action: 'AI布局优化', icon: Command },
        { key: 'Ctrl + Shift + A', action: '打开AI助手', icon: Command },
      ]
    }
  ];

  const filteredShortcuts = shortcuts.map(category => ({
    ...category,
    items: category.items.filter(item => 
      item.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.key.toLowerCase().includes(searchTerm.toLowerCase())
    )
  })).filter(category => category.items.length > 0);

  // 键盘事件监听
  useEffect(() => {
    const handleKeyDown = (e) => {
      // 如果快捷键面板打开，按 Escape 关闭
      if (isOpen && e.key === 'Escape') {
        onClose();
      }
      
      // Ctrl + / 打开快捷键面板
      if (e.ctrlKey && e.key === '/') {
        e.preventDefault();
        if (isOpen) {
          onClose();
        } else {
          // 这里需要从父组件传入打开函数
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <Card className="w-full max-w-4xl max-h-[80vh] overflow-hidden">
        <CardHeader className="border-b">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Keyboard className="w-5 h-5 text-blue-600" />
              <CardTitle>键盘快捷键</CardTitle>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
          <div className="mt-4">
            <input
              type="text"
              placeholder="搜索快捷键..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </CardHeader>
        
        <CardContent className="p-0 overflow-y-auto max-h-[60vh]">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
            {filteredShortcuts.map((category, categoryIndex) => (
              <div key={categoryIndex} className="p-6 border-b md:border-r last:border-b-0 md:even:border-r-0">
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  {category.category}
                  <Badge variant="secondary" className="ml-2 text-xs">
                    {category.items.length}
                  </Badge>
                </h3>
                
                <div className="space-y-3">
                  {category.items.map((item, itemIndex) => {
                    const Icon = item.icon;
                    return (
                      <div key={itemIndex} className="flex items-center justify-between group hover:bg-gray-50 p-2 rounded-md transition-colors">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-gray-100 rounded-md flex items-center justify-center group-hover:bg-gray-200 transition-colors">
                            <Icon className="w-4 h-4 text-gray-600" />
                          </div>
                          <span className="text-sm text-gray-700">{item.action}</span>
                        </div>
                        
                        <div className="flex items-center space-x-1">
                          {item.key.split(' + ').map((key, keyIndex) => (
                            <React.Fragment key={keyIndex}>
                              {keyIndex > 0 && <span className="text-gray-400 text-xs">+</span>}
                              <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs font-mono text-gray-700 shadow-sm">
                                {key}
                              </kbd>
                            </React.Fragment>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
          
          {filteredShortcuts.length === 0 && (
            <div className="p-8 text-center text-gray-500">
              <Keyboard className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p>没有找到匹配的快捷键</p>
              <p className="text-sm mt-1">尝试其他搜索词</p>
            </div>
          )}
        </CardContent>
        
        <div className="border-t p-4 bg-gray-50">
          <div className="flex items-center justify-between text-sm text-gray-600">
            <div className="flex items-center space-x-4">
              <span>💡 提示：按 <kbd className="px-1 py-0.5 bg-gray-200 rounded text-xs">Ctrl + /</kbd> 快速打开此面板</span>
            </div>
            <div className="flex items-center space-x-2">
              <span>按 <kbd className="px-1 py-0.5 bg-gray-200 rounded text-xs">Esc</kbd> 关闭</span>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default KeyboardShortcuts;
