import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Sparkles, 
  Send, 
  Wand2, 
  Palette, 
  Layout, 
  Type,
  Image,
  Lightbulb,
  Zap
} from 'lucide-react';

const AIAssistant = ({ isOpen, onClose }) => {
  const [message, setMessage] = useState('');
  const [suggestions, setSuggestions] = useState([
    {
      id: 1,
      type: 'style',
      title: '现代化按钮样式',
      description: '为选中的按钮应用现代化设计风格',
      icon: Wand2,
      color: 'bg-blue-500'
    },
    {
      id: 2,
      type: 'color',
      title: '和谐配色方案',
      description: '基于当前主色调生成和谐的配色方案',
      icon: Palette,
      color: 'bg-purple-500'
    },
    {
      id: 3,
      type: 'layout',
      title: '优化布局间距',
      description: '智能调整元素间距，提升视觉层次',
      icon: Layout,
      color: 'bg-green-500'
    },
    {
      id: 4,
      type: 'typography',
      title: '字体层级建议',
      description: '优化文本的字体大小和层级关系',
      icon: Type,
      color: 'bg-orange-500'
    }
  ]);

  const quickActions = [
    { label: '让这个按钮更醒目', icon: Zap },
    { label: '调整整体配色', icon: Palette },
    { label: '优化布局对齐', icon: Layout },
    { label: '生成图标建议', icon: Image },
  ];

  const handleSendMessage = () => {
    if (!message.trim()) return;
    
    // 模拟AI响应
    console.log('AI处理消息:', message);
    setMessage('');
    
    // 这里可以添加实际的AI API调用
  };

  const applySuggestion = (suggestion) => {
    console.log('应用AI建议:', suggestion);
    // 这里实现具体的样式应用逻辑
  };

  if (!isOpen) return null;

  return (
    <div className="fixed right-4 top-20 w-80 h-[calc(100vh-6rem)] bg-white rounded-lg shadow-xl border border-gray-200 flex flex-col z-50">
      {/* 头部 */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <h3 className="font-semibold text-gray-900">AI设计助手</h3>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            ×
          </Button>
        </div>
        <p className="text-sm text-gray-600 mt-1">
          智能分析您的设计，提供专业建议
        </p>
      </div>

      {/* AI建议卡片 */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-gray-900 flex items-center">
            <Lightbulb className="w-4 h-4 mr-2 text-yellow-500" />
            智能建议
          </h4>
          
          {suggestions.map((suggestion) => {
            const Icon = suggestion.icon;
            return (
              <Card key={suggestion.id} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardContent className="p-3">
                  <div className="flex items-start space-x-3">
                    <div className={`w-8 h-8 ${suggestion.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                      <Icon className="w-4 h-4 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h5 className="text-sm font-medium text-gray-900 mb-1">
                        {suggestion.title}
                      </h5>
                      <p className="text-xs text-gray-600 mb-2">
                        {suggestion.description}
                      </p>
                      <Button 
                        size="sm" 
                        className="h-7 text-xs"
                        onClick={() => applySuggestion(suggestion)}
                      >
                        应用建议
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* 快速操作 */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-gray-900">快速操作</h4>
          <div className="grid grid-cols-1 gap-2">
            {quickActions.map((action, index) => {
              const Icon = action.icon;
              return (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="justify-start h-8 text-xs"
                  onClick={() => setMessage(action.label)}
                >
                  <Icon className="w-3 h-3 mr-2" />
                  {action.label}
                </Button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 底部输入区域 */}
      <div className="p-4 border-t border-gray-200">
        <div className="flex space-x-2">
          <Input
            placeholder="描述您想要的修改..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            className="flex-1 text-sm"
          />
          <Button 
            size="sm" 
            onClick={handleSendMessage}
            disabled={!message.trim()}
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        <p className="text-xs text-gray-500 mt-2">
          例如："让这个按钮更醒目"、"调整配色更温暖"
        </p>
      </div>
    </div>
  );
};

export default AIAssistant;
