import React, { useState, useCallback, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import WelcomePage from './WelcomePage';
import Navbar from './Navbar';
import EnhancedDesignEditor from './EnhancedDesignEditor';
import EnhancedAIAssistant from './EnhancedAIAssistant';
import KeyboardShortcuts from './KeyboardShortcuts';
import { Sparkles, Keyboard, HelpCircle } from 'lucide-react';

const FinalApp = () => {
  const [showWelcome, setShowWelcome] = useState(true);
  const [isAIAssistantOpen, setIsAIAssistantOpen] = useState(false);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState(false);
  const [elements, setElements] = useState([]);
  const [selectedElement, setSelectedElement] = useState(null);
  const [showTutorial, setShowTutorial] = useState(false);

  // 处理AI助手应用的更改
  const handleAIChanges = useCallback((updatedElements) => {
    if (Array.isArray(updatedElements)) {
      // 批量更新元素
      setElements(prev => {
        const newElements = [...prev];
        updatedElements.forEach(updatedElement => {
          const index = newElements.findIndex(el => el.id === updatedElement.id);
          if (index !== -1) {
            newElements[index] = updatedElement;
          }
        });
        return newElements;
      });
      
      // 更新选中元素
      if (selectedElement && updatedElements.length === 1) {
        const updatedSelected = updatedElements.find(el => el.id === selectedElement.id);
        if (updatedSelected) {
          setSelectedElement(updatedSelected);
        }
      }
    } else {
      // 单个元素更新
      setElements(updatedElements);
    }
  }, [selectedElement]);

  // 从设计编辑器接收状态更新
  const handleEditorStateChange = useCallback((newElements, newSelectedElement) => {
    setElements(newElements);
    setSelectedElement(newSelectedElement);
  }, []);

  // 开始使用应用
  const handleGetStarted = () => {
    setShowWelcome(false);
    // 显示简单的新手引导
    setTimeout(() => {
      setShowTutorial(true);
      setTimeout(() => setShowTutorial(false), 5000);
    }, 1000);
  };

  // 全局键盘快捷键
  useEffect(() => {
    const handleKeyDown = (e) => {
      // Ctrl + / 打开快捷键面板
      if (e.ctrlKey && e.key === '/') {
        e.preventDefault();
        setIsShortcutsOpen(true);
      }
      
      // Ctrl + Shift + A 打开AI助手
      if (e.ctrlKey && e.shiftKey && e.key === 'A') {
        e.preventDefault();
        setIsAIAssistantOpen(true);
      }
      
      // F1 显示帮助
      if (e.key === 'F1') {
        e.preventDefault();
        setIsShortcutsOpen(true);
      }
    };

    if (!showWelcome) {
      document.addEventListener('keydown', handleKeyDown);
      return () => document.removeEventListener('keydown', handleKeyDown);
    }
  }, [showWelcome]);

  // 如果显示欢迎页面
  if (showWelcome) {
    return <WelcomePage onGetStarted={handleGetStarted} />;
  }

  return (
    <div className="h-screen flex flex-col bg-gray-50 relative">
      {/* 导航栏 */}
      <Navbar />
      
      {/* 主要内容区域 */}
      <div className="flex-1 relative">
        <EnhancedDesignEditor 
          onStateChange={handleEditorStateChange}
          externalElements={elements}
          externalSelectedElement={selectedElement}
        />
        
        {/* 浮动操作按钮组 */}
        <div className="fixed bottom-6 right-6 flex flex-col space-y-3 z-40">
          {/* 快捷键帮助按钮 */}
          <Button
            variant="outline"
            size="sm"
            className="w-12 h-12 rounded-full shadow-lg bg-white hover:bg-gray-50 border-gray-200"
            onClick={() => setIsShortcutsOpen(true)}
            title="键盘快捷键 (Ctrl + /)"
          >
            <Keyboard className="w-5 h-5 text-gray-600" />
          </Button>
          
          {/* 帮助按钮 */}
          <Button
            variant="outline"
            size="sm"
            className="w-12 h-12 rounded-full shadow-lg bg-white hover:bg-gray-50 border-gray-200"
            onClick={() => setShowTutorial(true)}
            title="帮助和教程"
          >
            <HelpCircle className="w-5 h-5 text-gray-600" />
          </Button>
          
          {/* AI助手按钮 */}
          <Button
            className={`w-14 h-14 rounded-full shadow-lg transition-all duration-200 hover:scale-110 ${
              isAIAssistantOpen 
                ? 'bg-gradient-to-br from-purple-600 to-pink-600' 
                : 'bg-gradient-to-br from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600'
            }`}
            onClick={() => setIsAIAssistantOpen(!isAIAssistantOpen)}
            title="AI设计助手 (Ctrl + Shift + A)"
          >
            <Sparkles className="w-6 h-6 text-white" />
          </Button>
        </div>
        
        {/* AI助手面板 */}
        <EnhancedAIAssistant 
          isOpen={isAIAssistantOpen} 
          onClose={() => setIsAIAssistantOpen(false)}
          selectedElement={selectedElement}
          elements={elements}
          onApplyChanges={handleAIChanges}
        />
        
        {/* 键盘快捷键面板 */}
        <KeyboardShortcuts 
          isOpen={isShortcutsOpen}
          onClose={() => setIsShortcutsOpen(false)}
        />
        
        {/* 新手引导提示 */}
        {showTutorial && (
          <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50">
            <div className="bg-blue-600 text-white px-6 py-3 rounded-lg shadow-lg flex items-center space-x-3 animate-bounce">
              <Sparkles className="w-5 h-5" />
              <span className="font-medium">
                欢迎使用 DesignCraft！点击右下角的 AI 按钮开始体验智能设计功能
              </span>
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-white hover:bg-blue-700"
                onClick={() => setShowTutorial(false)}
              >
                ×
              </Button>
            </div>
          </div>
        )}
        
        {/* 状态栏 */}
        <div className="absolute bottom-0 left-0 right-0 h-6 bg-gray-800 text-white text-xs flex items-center justify-between px-4">
          <div className="flex items-center space-x-4">
            <span>元素: {elements.length}</span>
            {selectedElement && (
              <span>选中: {selectedElement.type}</span>
            )}
          </div>
          <div className="flex items-center space-x-4">
            <span>按 Ctrl + / 查看快捷键</span>
            <span>按 F1 获取帮助</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FinalApp;
