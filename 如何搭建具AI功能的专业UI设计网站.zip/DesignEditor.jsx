import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { 
  Square, 
  Circle, 
  Type, 
  Image, 
  Move, 
  MousePointer, 
  Layers,
  Palette,
  Sparkles,
  Download,
  Save,
  Undo,
  Redo
} from 'lucide-react';

const DesignEditor = () => {
  const canvasRef = useRef(null);
  const [selectedTool, setSelectedTool] = useState('select');
  const [elements, setElements] = useState([]);
  const [selectedElement, setSelectedElement] = useState(null);
  const [isDrawing, setIsDrawing] = useState(false);

  // 工具栏配置
  const tools = [
    { id: 'select', icon: MousePointer, label: '选择' },
    { id: 'move', icon: Move, label: '移动' },
    { id: 'rectangle', icon: Square, label: '矩形' },
    { id: 'circle', icon: Circle, label: '圆形' },
    { id: 'text', icon: Type, label: '文本' },
    { id: 'image', icon: Image, label: '图片' },
  ];

  // AI功能按钮
  const aiFeatures = [
    { id: 'ai-style', icon: Sparkles, label: 'AI样式推荐' },
    { id: 'ai-layout', icon: Layers, label: 'AI布局优化' },
    { id: 'ai-color', icon: Palette, label: 'AI配色建议' },
  ];

  // 画布事件处理
  const handleCanvasMouseDown = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (selectedTool === 'rectangle' || selectedTool === 'circle') {
      setIsDrawing(true);
      const newElement = {
        id: Date.now(),
        type: selectedTool,
        x,
        y,
        width: 0,
        height: 0,
        style: {
          fill: '#3b82f6',
          stroke: '#1e40af',
          strokeWidth: 2
        }
      };
      setElements([...elements, newElement]);
    } else if (selectedTool === 'text') {
      const newElement = {
        id: Date.now(),
        type: 'text',
        x,
        y,
        content: '文本内容',
        style: {
          fontSize: 16,
          fontFamily: 'Arial',
          color: '#1f2937'
        }
      };
      setElements([...elements, newElement]);
    }
  };

  const handleCanvasMouseMove = (e) => {
    if (!isDrawing) return;

    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setElements(prev => {
      const newElements = [...prev];
      const lastElement = newElements[newElements.length - 1];
      if (lastElement) {
        lastElement.width = x - lastElement.x;
        lastElement.height = y - lastElement.y;
      }
      return newElements;
    });
  };

  const handleCanvasMouseUp = () => {
    setIsDrawing(false);
  };

  // 渲染画布内容
  const renderCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // 绘制网格背景
    ctx.strokeStyle = '#f3f4f6';
    ctx.lineWidth = 1;
    for (let i = 0; i < canvas.width; i += 20) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, canvas.height);
      ctx.stroke();
    }
    for (let i = 0; i < canvas.height; i += 20) {
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(canvas.width, i);
      ctx.stroke();
    }

    // 绘制元素
    elements.forEach(element => {
      ctx.save();
      
      if (element.type === 'rectangle') {
        ctx.fillStyle = element.style.fill;
        ctx.strokeStyle = element.style.stroke;
        ctx.lineWidth = element.style.strokeWidth;
        ctx.fillRect(element.x, element.y, element.width, element.height);
        ctx.strokeRect(element.x, element.y, element.width, element.height);
      } else if (element.type === 'circle') {
        const centerX = element.x + element.width / 2;
        const centerY = element.y + element.height / 2;
        const radius = Math.min(Math.abs(element.width), Math.abs(element.height)) / 2;
        
        ctx.fillStyle = element.style.fill;
        ctx.strokeStyle = element.style.stroke;
        ctx.lineWidth = element.style.strokeWidth;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();
      } else if (element.type === 'text') {
        ctx.fillStyle = element.style.color;
        ctx.font = `${element.style.fontSize}px ${element.style.fontFamily}`;
        ctx.fillText(element.content, element.x, element.y);
      }
      
      ctx.restore();
    });
  };

  useEffect(() => {
    renderCanvas();
  }, [elements]);

  // AI功能处理
  const handleAIFeature = (featureId) => {
    if (!selectedElement) {
      alert('请先选择一个元素');
      return;
    }

    switch (featureId) {
      case 'ai-style':
        // 模拟AI样式推荐
        setElements(prev => prev.map(el => 
          el.id === selectedElement.id 
            ? { 
                ...el, 
                style: { 
                  ...el.style, 
                  fill: '#10b981',
                  stroke: '#059669'
                }
              }
            : el
        ));
        break;
      case 'ai-layout':
        // 模拟AI布局优化
        alert('AI布局优化功能：自动对齐和分布元素');
        break;
      case 'ai-color':
        // 模拟AI配色建议
        alert('AI配色建议：基于色彩理论推荐和谐配色方案');
        break;
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* 左侧工具栏 */}
      <div className="w-16 bg-white border-r border-gray-200 flex flex-col items-center py-4 space-y-2">
        {tools.map((tool) => {
          const Icon = tool.icon;
          return (
            <Button
              key={tool.id}
              variant={selectedTool === tool.id ? "default" : "ghost"}
              size="sm"
              className="w-10 h-10 p-0"
              onClick={() => setSelectedTool(tool.id)}
              title={tool.label}
            >
              <Icon className="w-4 h-4" />
            </Button>
          );
        })}
        
        <Separator className="w-8" />
        
        {/* AI功能按钮 */}
        {aiFeatures.map((feature) => {
          const Icon = feature.icon;
          return (
            <Button
              key={feature.id}
              variant="outline"
              size="sm"
              className="w-10 h-10 p-0 border-purple-200 text-purple-600 hover:bg-purple-50"
              onClick={() => handleAIFeature(feature.id)}
              title={feature.label}
            >
              <Icon className="w-4 h-4" />
            </Button>
          );
        })}
      </div>

      {/* 主编辑区域 */}
      <div className="flex-1 flex flex-col">
        {/* 顶部工具栏 */}
        <div className="h-12 bg-white border-b border-gray-200 flex items-center px-4 space-x-2">
          <Button variant="ghost" size="sm">
            <Undo className="w-4 h-4 mr-1" />
            撤销
          </Button>
          <Button variant="ghost" size="sm">
            <Redo className="w-4 h-4 mr-1" />
            重做
          </Button>
          <Separator orientation="vertical" className="h-6" />
          <Button variant="ghost" size="sm">
            <Save className="w-4 h-4 mr-1" />
            保存
          </Button>
          <Button variant="ghost" size="sm">
            <Download className="w-4 h-4 mr-1" />
            导出
          </Button>
        </div>

        {/* 画布区域 */}
        <div className="flex-1 overflow-auto p-4">
          <Card className="w-full h-full min-h-[600px] bg-white shadow-sm">
            <canvas
              ref={canvasRef}
              width={800}
              height={600}
              className="w-full h-full cursor-crosshair"
              onMouseDown={handleCanvasMouseDown}
              onMouseMove={handleCanvasMouseMove}
              onMouseUp={handleCanvasMouseUp}
            />
          </Card>
        </div>
      </div>

      {/* 右侧属性面板 */}
      <div className="w-64 bg-white border-l border-gray-200 p-4">
        <h3 className="text-sm font-medium text-gray-900 mb-4">属性面板</h3>
        
        {selectedElement ? (
          <div className="space-y-4">
            <div>
              <label className="text-xs text-gray-500">元素类型</label>
              <p className="text-sm font-medium">{selectedElement.type}</p>
            </div>
            <div>
              <label className="text-xs text-gray-500">位置</label>
              <p className="text-sm">X: {selectedElement.x}, Y: {selectedElement.y}</p>
            </div>
            {selectedElement.width && (
              <div>
                <label className="text-xs text-gray-500">尺寸</label>
                <p className="text-sm">W: {selectedElement.width}, H: {selectedElement.height}</p>
              </div>
            )}
          </div>
        ) : (
          <p className="text-sm text-gray-500">选择一个元素查看属性</p>
        )}

        <Separator className="my-6" />

        {/* AI功能说明 */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-purple-900">AI功能</h4>
          <div className="space-y-2">
            <div className="p-2 bg-purple-50 rounded-md">
              <p className="text-xs text-purple-700">
                <Sparkles className="w-3 h-3 inline mr-1" />
                AI样式推荐：一键优化元素样式
              </p>
            </div>
            <div className="p-2 bg-purple-50 rounded-md">
              <p className="text-xs text-purple-700">
                <Layers className="w-3 h-3 inline mr-1" />
                AI布局优化：智能调整元素布局
              </p>
            </div>
            <div className="p-2 bg-purple-50 rounded-md">
              <p className="text-xs text-purple-700">
                <Palette className="w-3 h-3 inline mr-1" />
                AI配色建议：推荐和谐配色方案
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DesignEditor;
