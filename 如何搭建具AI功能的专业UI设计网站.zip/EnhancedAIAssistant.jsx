import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Sparkles, 
  Send, 
  Wand2, 
  Palette, 
  Layout, 
  Type,
  Image,
  Lightbulb,
  Zap,
  Loader2,
  CheckCircle,
  TrendingUp,
  Eye,
  Cpu
} from 'lucide-react';
import { aiService } from '../services/aiService';

const EnhancedAIAssistant = ({ isOpen, onClose, selectedElement, elements, onApplyChanges }) => {
  const [message, setMessage] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [styleSuggestions, setStyleSuggestions] = useState([]);
  const [colorPalettes, setColorPalettes] = useState([]);
  const [designAnalysis, setDesignAnalysis] = useState(null);
  const [activeTab, setActiveTab] = useState('suggestions');

  // 当选中元素改变时，自动生成建议
  useEffect(() => {
    if (selectedElement && isOpen) {
      generateStyleSuggestions();
    }
  }, [selectedElement, isOpen]);

  // 生成样式建议
  const generateStyleSuggestions = async () => {
    if (!selectedElement) return;
    
    setIsProcessing(true);
    try {
      const suggestions = await aiService.generateStyleSuggestions(selectedElement);
      setStyleSuggestions(suggestions);
    } catch (error) {
      console.error('生成样式建议失败:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  // 生成配色方案
  const generateColorPalettes = async () => {
    setIsProcessing(true);
    try {
      const palettes = await aiService.generateColorPalette('#3b82f6');
      setColorPalettes(palettes);
    } catch (error) {
      console.error('生成配色方案失败:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  // 分析设计趋势
  const analyzeDesign = async () => {
    setIsProcessing(true);
    try {
      const analysis = await aiService.analyzeDesignTrends(elements);
      setDesignAnalysis(analysis);
    } catch (error) {
      console.error('设计分析失败:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  // 优化布局
  const optimizeLayout = async () => {
    setIsProcessing(true);
    try {
      const result = await aiService.optimizeLayout(elements);
      onApplyChanges(result.elements);
      // 显示改进信息
      alert(`布局优化完成！\n${result.improvements.join('\n')}`);
    } catch (error) {
      console.error('布局优化失败:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  // 应用样式建议
  const applyStyleSuggestion = (suggestion) => {
    if (!selectedElement) return;
    
    const updatedElement = {
      ...selectedElement,
      style: { ...selectedElement.style, ...suggestion.style }
    };
    
    onApplyChanges([updatedElement]);
  };

  // 应用配色方案
  const applyColorPalette = (palette) => {
    if (!selectedElement) return;
    
    const primaryColor = palette.colors[0];
    const updatedElement = {
      ...selectedElement,
      style: { 
        ...selectedElement.style, 
        fill: primaryColor,
        stroke: palette.colors[1] || primaryColor
      }
    };
    
    onApplyChanges([updatedElement]);
  };

  // 处理自然语言输入
  const handleNaturalLanguageInput = async () => {
    if (!message.trim() || !selectedElement) return;
    
    setIsProcessing(true);
    
    // 模拟自然语言处理
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // 简单的关键词匹配和响应
    const lowerMessage = message.toLowerCase();
    let response = '';
    
    if (lowerMessage.includes('颜色') || lowerMessage.includes('配色')) {
      await generateColorPalettes();
      response = '已为您生成新的配色建议！';
      setActiveTab('colors');
    } else if (lowerMessage.includes('大') || lowerMessage.includes('尺寸')) {
      const updatedElement = {
        ...selectedElement,
        width: (selectedElement.width || 100) * 1.2,
        height: (selectedElement.height || 100) * 1.2
      };
      onApplyChanges([updatedElement]);
      response = '已增大元素尺寸！';
    } else if (lowerMessage.includes('小')) {
      const updatedElement = {
        ...selectedElement,
        width: (selectedElement.width || 100) * 0.8,
        height: (selectedElement.height || 100) * 0.8
      };
      onApplyChanges([updatedElement]);
      response = '已减小元素尺寸！';
    } else if (lowerMessage.includes('圆角') || lowerMessage.includes('圆润')) {
      const updatedElement = {
        ...selectedElement,
        style: { ...selectedElement.style, borderRadius: 12 }
      };
      onApplyChanges([updatedElement]);
      response = '已添加圆角效果！';
    } else {
      await generateStyleSuggestions();
      response = '已为您生成新的样式建议！';
      setActiveTab('suggestions');
    }
    
    setMessage('');
    setIsProcessing(false);
    
    // 显示响应
    setTimeout(() => alert(response), 100);
  };

  const quickActions = [
    { 
      label: '让这个元素更醒目', 
      icon: Zap,
      action: () => setMessage('让这个元素更醒目')
    },
    { 
      label: '调整配色更和谐', 
      icon: Palette,
      action: () => setMessage('调整配色更和谐')
    },
    { 
      label: '优化整体布局', 
      icon: Layout,
      action: optimizeLayout
    },
    { 
      label: '增加圆角效果', 
      icon: Eye,
      action: () => setMessage('增加圆角效果')
    },
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed right-4 top-20 w-96 h-[calc(100vh-6rem)] bg-white rounded-lg shadow-xl border border-gray-200 flex flex-col z-50">
      {/* 头部 */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <h3 className="font-semibold text-gray-900">AI设计助手</h3>
            {isProcessing && <Loader2 className="w-4 h-4 animate-spin text-purple-500" />}
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            ×
          </Button>
        </div>
        <p className="text-sm text-gray-600 mt-1">
          智能分析您的设计，提供专业建议
        </p>
      </div>

      {/* 标签页内容 */}
      <div className="flex-1 overflow-hidden">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
          <TabsList className="grid w-full grid-cols-4 mx-4 mt-4">
            <TabsTrigger value="suggestions" className="text-xs">建议</TabsTrigger>
            <TabsTrigger value="colors" className="text-xs">配色</TabsTrigger>
            <TabsTrigger value="layout" className="text-xs">布局</TabsTrigger>
            <TabsTrigger value="analysis" className="text-xs">分析</TabsTrigger>
          </TabsList>

          <div className="flex-1 overflow-y-auto p-4">
            {/* 样式建议标签页 */}
            <TabsContent value="suggestions" className="space-y-3 mt-0">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-medium text-gray-900">智能样式建议</h4>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={generateStyleSuggestions}
                  disabled={!selectedElement || isProcessing}
                >
                  <Wand2 className="w-3 h-3 mr-1" />
                  刷新
                </Button>
              </div>
              
              {!selectedElement ? (
                <p className="text-sm text-gray-500">请先选择一个元素</p>
              ) : styleSuggestions.length > 0 ? (
                styleSuggestions.map((suggestion) => (
                  <Card key={suggestion.id} className="cursor-pointer hover:shadow-md transition-shadow">
                    <CardContent className="p-3">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h5 className="text-sm font-medium text-gray-900">
                            {suggestion.name}
                          </h5>
                          <p className="text-xs text-gray-600">
                            {suggestion.description}
                          </p>
                        </div>
                        <Badge variant="secondary" className="text-xs">
                          {Math.round(suggestion.confidence * 100)}%
                        </Badge>
                      </div>
                      <Button 
                        size="sm" 
                        className="h-7 text-xs w-full"
                        onClick={() => applyStyleSuggestion(suggestion)}
                      >
                        应用样式
                      </Button>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="text-center py-4">
                  <Lightbulb className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-500">选择元素后自动生成建议</p>
                </div>
              )}
            </TabsContent>

            {/* 配色方案标签页 */}
            <TabsContent value="colors" className="space-y-3 mt-0">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-medium text-gray-900">AI配色方案</h4>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={generateColorPalettes}
                  disabled={isProcessing}
                >
                  <Palette className="w-3 h-3 mr-1" />
                  生成
                </Button>
              </div>
              
              {colorPalettes.length > 0 ? (
                colorPalettes.map((palette) => (
                  <Card key={palette.id} className="cursor-pointer hover:shadow-md transition-shadow">
                    <CardContent className="p-3">
                      <div className="mb-2">
                        <h5 className="text-sm font-medium text-gray-900">
                          {palette.name}
                        </h5>
                        <p className="text-xs text-gray-600">
                          {palette.description}
                        </p>
                      </div>
                      <div className="flex space-x-1 mb-2">
                        {palette.colors.map((color, index) => (
                          <div 
                            key={index}
                            className="w-6 h-6 rounded border border-gray-200"
                            style={{ backgroundColor: color }}
                            title={color}
                          />
                        ))}
                      </div>
                      <Button 
                        size="sm" 
                        className="h-7 text-xs w-full"
                        onClick={() => applyColorPalette(palette)}
                        disabled={!selectedElement}
                      >
                        应用配色
                      </Button>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="text-center py-4">
                  <Palette className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-500">点击生成按钮获取配色建议</p>
                </div>
              )}
            </TabsContent>

            {/* 布局优化标签页 */}
            <TabsContent value="layout" className="space-y-3 mt-0">
              <h4 className="text-sm font-medium text-gray-900">布局优化</h4>
              
              <Card>
                <CardContent className="p-3">
                  <div className="flex items-center space-x-2 mb-2">
                    <Layout className="w-4 h-4 text-blue-500" />
                    <span className="text-sm font-medium">智能布局优化</span>
                  </div>
                  <p className="text-xs text-gray-600 mb-3">
                    AI将自动优化元素对齐、间距和整体布局
                  </p>
                  <Button 
                    size="sm" 
                    className="h-7 text-xs w-full"
                    onClick={optimizeLayout}
                    disabled={elements.length === 0 || isProcessing}
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                        优化中...
                      </>
                    ) : (
                      '开始优化'
                    )}
                  </Button>
                </CardContent>
              </Card>

              <div className="space-y-2">
                <h5 className="text-xs font-medium text-gray-700">快速操作</h5>
                {quickActions.map((action, index) => {
                  const Icon = action.icon;
                  return (
                    <Button
                      key={index}
                      variant="outline"
                      size="sm"
                      className="justify-start h-8 text-xs w-full"
                      onClick={action.action}
                      disabled={isProcessing}
                    >
                      <Icon className="w-3 h-3 mr-2" />
                      {action.label}
                    </Button>
                  );
                })}
              </div>
            </TabsContent>

            {/* 设计分析标签页 */}
            <TabsContent value="analysis" className="space-y-3 mt-0">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-medium text-gray-900">设计分析</h4>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={analyzeDesign}
                  disabled={isProcessing}
                >
                  <TrendingUp className="w-3 h-3 mr-1" />
                  分析
                </Button>
              </div>
              
              {designAnalysis ? (
                <div className="space-y-3">
                  <Card>
                    <CardContent className="p-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">整体评分</span>
                        <Badge variant="secondary">
                          {Math.round(designAnalysis.overallScore * 100)}分
                        </Badge>
                      </div>
                      <Progress value={designAnalysis.overallScore * 100} className="h-2" />
                    </CardContent>
                  </Card>
                  
                  {designAnalysis.trends.map((trend) => (
                    <Card key={trend.id}>
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium">{trend.name}</span>
                          <Badge variant={trend.score > 0.8 ? "default" : "secondary"}>
                            {Math.round(trend.score * 100)}%
                          </Badge>
                        </div>
                        <p className="text-xs text-gray-600 mb-2">{trend.description}</p>
                        <Progress value={trend.score * 100} className="h-1" />
                      </CardContent>
                    </Card>
                  ))}
                  
                  <Card>
                    <CardContent className="p-3">
                      <h5 className="text-sm font-medium mb-2">改进建议</h5>
                      <ul className="space-y-1">
                        {designAnalysis.recommendations.map((rec, index) => (
                          <li key={index} className="text-xs text-gray-600 flex items-start">
                            <CheckCircle className="w-3 h-3 text-green-500 mr-1 mt-0.5 flex-shrink-0" />
                            {rec}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <div className="text-center py-4">
                  <Cpu className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-500">点击分析按钮获取设计评估</p>
                </div>
              )}
            </TabsContent>
          </div>
        </Tabs>
      </div>

      {/* 底部输入区域 */}
      <div className="p-4 border-t border-gray-200">
        <div className="flex space-x-2">
          <Input
            placeholder="描述您想要的修改..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleNaturalLanguageInput()}
            className="flex-1 text-sm"
            disabled={isProcessing}
          />
          <Button 
            size="sm" 
            onClick={handleNaturalLanguageInput}
            disabled={!message.trim() || !selectedElement || isProcessing}
          >
            {isProcessing ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </div>
        <p className="text-xs text-gray-500 mt-2">
          例如："让这个按钮更醒目"、"调整配色更温暖"、"增加圆角"
        </p>
      </div>
    </div>
  );
};

export default EnhancedAIAssistant;
