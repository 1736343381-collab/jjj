import React, { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import Navbar from './Navbar';
import EnhancedDesignEditor from './EnhancedDesignEditor';
import EnhancedAIAssistant from './EnhancedAIAssistant';
import { Sparkles } from 'lucide-react';

const IntegratedApp = () => {
  const [isAIAssistantOpen, setIsAIAssistantOpen] = useState(false);
  const [elements, setElements] = useState([]);
  const [selectedElement, setSelectedElement] = useState(null);

  // 处理AI助手应用的更改
  const handleAIChanges = useCallback((updatedElements) => {
    if (Array.isArray(updatedElements)) {
      // 批量更新元素
      setElements(prev => {
        const newElements = [...prev];
        updatedElements.forEach(updatedElement => {
          const index = newElements.findIndex(el => el.id === updatedElement.id);
          if (index !== -1) {
            newElements[index] = updatedElement;
          }
        });
        return newElements;
      });
      
      // 更新选中元素
      if (selectedElement && updatedElements.length === 1) {
        const updatedSelected = updatedElements.find(el => el.id === selectedElement.id);
        if (updatedSelected) {
          setSelectedElement(updatedSelected);
        }
      }
    } else {
      // 单个元素更新
      setElements(updatedElements);
    }
  }, [selectedElement]);

  // 从设计编辑器接收状态更新
  const handleEditorStateChange = useCallback((newElements, newSelectedElement) => {
    setElements(newElements);
    setSelectedElement(newSelectedElement);
  }, []);

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* 导航栏 */}
      <Navbar />
      
      {/* 主要内容区域 */}
      <div className="flex-1 relative">
        <EnhancedDesignEditor 
          onStateChange={handleEditorStateChange}
          externalElements={elements}
          externalSelectedElement={selectedElement}
        />
        
        {/* AI助手触发按钮 */}
        <Button
          className="fixed bottom-6 right-6 w-14 h-14 rounded-full shadow-lg bg-gradient-to-br from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 z-40 transition-all duration-200 hover:scale-110"
          onClick={() => setIsAIAssistantOpen(!isAIAssistantOpen)}
        >
          <Sparkles className="w-6 h-6 text-white" />
        </Button>
        
        {/* AI助手面板 */}
        <EnhancedAIAssistant 
          isOpen={isAIAssistantOpen} 
          onClose={() => setIsAIAssistantOpen(false)}
          selectedElement={selectedElement}
          elements={elements}
          onApplyChanges={handleAIChanges}
        />
      </div>
    </div>
  );
};

export default IntegratedApp;
