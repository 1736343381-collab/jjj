import React from 'react';
import { Button } from '@/components/ui/button';
import { 
  Palette, 
  User, 
  Settings, 
  HelpCircle,
  Share2,
  FileText,
  Folder
} from 'lucide-react';

const Navbar = () => {
  return (
    <nav className="h-14 bg-white border-b border-gray-200 flex items-center justify-between px-6">
      {/* 左侧 - Logo和项目信息 */}
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-600 rounded-lg flex items-center justify-center">
            <Palette className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-bold text-gray-900">DesignCraft</span>
        </div>
        
        <div className="h-6 w-px bg-gray-300" />
        
        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <Folder className="w-4 h-4" />
          <span>我的项目</span>
          <span>/</span>
          <span className="font-medium text-gray-900">新建设计稿</span>
        </div>
      </div>

      {/* 中间 - 主要操作按钮 */}
      <div className="flex items-center space-x-2">
        <Button variant="ghost" size="sm">
          <FileText className="w-4 h-4 mr-2" />
          文件
        </Button>
        <Button variant="ghost" size="sm">
          编辑
        </Button>
        <Button variant="ghost" size="sm">
          视图
        </Button>
        <Button variant="ghost" size="sm">
          对象
        </Button>
        <Button variant="ghost" size="sm">
          文本
        </Button>
      </div>

      {/* 右侧 - 用户操作 */}
      <div className="flex items-center space-x-2">
        <Button variant="outline" size="sm">
          <Share2 className="w-4 h-4 mr-2" />
          分享
        </Button>
        
        <div className="h-6 w-px bg-gray-300" />
        
        <Button variant="ghost" size="sm">
          <HelpCircle className="w-4 h-4" />
        </Button>
        <Button variant="ghost" size="sm">
          <Settings className="w-4 h-4" />
        </Button>
        <Button variant="ghost" size="sm">
          <User className="w-4 h-4" />
        </Button>
      </div>
    </nav>
  );
};

export default Navbar;
