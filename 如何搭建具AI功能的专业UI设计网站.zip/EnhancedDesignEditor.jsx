import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { 
  Square, 
  Circle, 
  Type, 
  Image, 
  Move, 
  MousePointer, 
  Layers,
  Palette,
  Sparkles,
  Download,
  Save,
  Undo,
  Redo,
  Copy,
  Trash2,
  RotateCw,
  ZoomIn,
  ZoomOut,
  Grid,
  Eye,
  EyeOff
} from 'lucide-react';

const EnhancedDesignEditor = () => {
  const canvasRef = useRef(null);
  const [selectedTool, setSelectedTool] = useState('select');
  const [elements, setElements] = useState([]);
  const [selectedElement, setSelectedElement] = useState(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [dragStart, setDragStart] = useState(null);
  const [zoom, setZoom] = useState(100);
  const [showGrid, setShowGrid] = useState(true);
  const [history, setHistory] = useState([]);
  const [historyIndex, setHistoryIndex] = useState(-1);

  // 工具栏配置
  const tools = [
    { id: 'select', icon: MousePointer, label: '选择' },
    { id: 'move', icon: Move, label: '移动' },
    { id: 'rectangle', icon: Square, label: '矩形' },
    { id: 'circle', icon: Circle, label: '圆形' },
    { id: 'text', icon: Type, label: '文本' },
    { id: 'image', icon: Image, label: '图片' },
  ];

  // AI功能按钮
  const aiFeatures = [
    { id: 'ai-style', icon: Sparkles, label: 'AI样式推荐' },
    { id: 'ai-layout', icon: Layers, label: 'AI布局优化' },
    { id: 'ai-color', icon: Palette, label: 'AI配色建议' },
  ];

  // 保存历史状态
  const saveToHistory = useCallback((newElements) => {
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(JSON.parse(JSON.stringify(newElements)));
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  }, [history, historyIndex]);

  // 撤销操作
  const undo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setElements(JSON.parse(JSON.stringify(history[historyIndex - 1])));
    }
  };

  // 重做操作
  const redo = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setElements(JSON.parse(JSON.stringify(history[historyIndex + 1])));
    }
  };

  // 获取鼠标在画布上的坐标
  const getCanvasCoordinates = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    return {
      x: (e.clientX - rect.left) * (canvas.width / rect.width),
      y: (e.clientY - rect.top) * (canvas.height / rect.height)
    };
  };

  // 检查点是否在元素内
  const isPointInElement = (point, element) => {
    if (element.type === 'circle') {
      const centerX = element.x + element.width / 2;
      const centerY = element.y + element.height / 2;
      const radius = Math.min(Math.abs(element.width), Math.abs(element.height)) / 2;
      const distance = Math.sqrt(Math.pow(point.x - centerX, 2) + Math.pow(point.y - centerY, 2));
      return distance <= radius;
    } else {
      return point.x >= element.x && 
             point.x <= element.x + element.width &&
             point.y >= element.y && 
             point.y <= element.y + element.height;
    }
  };

  // 画布事件处理
  const handleCanvasMouseDown = (e) => {
    const coords = getCanvasCoordinates(e);

    if (selectedTool === 'select') {
      // 查找被点击的元素
      const clickedElement = elements.find(el => isPointInElement(coords, el));
      setSelectedElement(clickedElement || null);
      
      if (clickedElement) {
        setDragStart({ x: coords.x - clickedElement.x, y: coords.y - clickedElement.y });
        setIsDrawing(true);
      }
    } else if (selectedTool === 'rectangle' || selectedTool === 'circle') {
      setIsDrawing(true);
      const newElement = {
        id: Date.now(),
        type: selectedTool,
        x: coords.x,
        y: coords.y,
        width: 0,
        height: 0,
        style: {
          fill: '#3b82f6',
          stroke: '#1e40af',
          strokeWidth: 2,
          opacity: 1
        }
      };
      const newElements = [...elements, newElement];
      setElements(newElements);
      setSelectedElement(newElement);
    } else if (selectedTool === 'text') {
      const newElement = {
        id: Date.now(),
        type: 'text',
        x: coords.x,
        y: coords.y,
        content: '文本内容',
        style: {
          fontSize: 16,
          fontFamily: 'Arial',
          color: '#1f2937',
          fontWeight: 'normal'
        }
      };
      const newElements = [...elements, newElement];
      setElements(newElements);
      setSelectedElement(newElement);
      saveToHistory(newElements);
    }
  };

  const handleCanvasMouseMove = (e) => {
    if (!isDrawing) return;

    const coords = getCanvasCoordinates(e);

    if (selectedTool === 'select' && selectedElement && dragStart) {
      // 移动选中的元素
      setElements(prev => prev.map(el => 
        el.id === selectedElement.id 
          ? { ...el, x: coords.x - dragStart.x, y: coords.y - dragStart.y }
          : el
      ));
    } else if ((selectedTool === 'rectangle' || selectedTool === 'circle') && selectedElement) {
      // 调整正在绘制的元素大小
      setElements(prev => prev.map(el => 
        el.id === selectedElement.id 
          ? { ...el, width: coords.x - el.x, height: coords.y - el.y }
          : el
      ));
    }
  };

  const handleCanvasMouseUp = () => {
    if (isDrawing && (selectedTool === 'rectangle' || selectedTool === 'circle' || selectedTool === 'select')) {
      saveToHistory(elements);
    }
    setIsDrawing(false);
    setDragStart(null);
  };

  // 渲染画布内容
  const renderCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // 绘制网格背景
    if (showGrid) {
      ctx.strokeStyle = '#f3f4f6';
      ctx.lineWidth = 1;
      const gridSize = 20;
      for (let i = 0; i < canvas.width; i += gridSize) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, canvas.height);
        ctx.stroke();
      }
      for (let i = 0; i < canvas.height; i += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, i);
        ctx.lineTo(canvas.width, i);
        ctx.stroke();
      }
    }

    // 绘制元素
    elements.forEach(element => {
      ctx.save();
      ctx.globalAlpha = element.style?.opacity || 1;
      
      if (element.type === 'rectangle') {
        ctx.fillStyle = element.style.fill;
        ctx.strokeStyle = element.style.stroke;
        ctx.lineWidth = element.style.strokeWidth;
        ctx.fillRect(element.x, element.y, element.width, element.height);
        ctx.strokeRect(element.x, element.y, element.width, element.height);
      } else if (element.type === 'circle') {
        const centerX = element.x + element.width / 2;
        const centerY = element.y + element.height / 2;
        const radius = Math.min(Math.abs(element.width), Math.abs(element.height)) / 2;
        
        ctx.fillStyle = element.style.fill;
        ctx.strokeStyle = element.style.stroke;
        ctx.lineWidth = element.style.strokeWidth;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();
      } else if (element.type === 'text') {
        ctx.fillStyle = element.style.color;
        ctx.font = `${element.style.fontWeight} ${element.style.fontSize}px ${element.style.fontFamily}`;
        ctx.fillText(element.content, element.x, element.y);
      }
      
      // 绘制选中状态的边框
      if (selectedElement && element.id === selectedElement.id) {
        ctx.strokeStyle = '#3b82f6';
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 5]);
        if (element.type === 'text') {
          const textMetrics = ctx.measureText(element.content);
          ctx.strokeRect(element.x - 2, element.y - element.style.fontSize - 2, 
                        textMetrics.width + 4, element.style.fontSize + 4);
        } else {
          ctx.strokeRect(element.x - 2, element.y - 2, element.width + 4, element.height + 4);
        }
        ctx.setLineDash([]);
      }
      
      ctx.restore();
    });
  };

  useEffect(() => {
    renderCanvas();
  }, [elements, selectedElement, showGrid]);

  // 删除选中元素
  const deleteSelectedElement = () => {
    if (selectedElement) {
      const newElements = elements.filter(el => el.id !== selectedElement.id);
      setElements(newElements);
      setSelectedElement(null);
      saveToHistory(newElements);
    }
  };

  // 复制选中元素
  const copySelectedElement = () => {
    if (selectedElement) {
      const newElement = {
        ...selectedElement,
        id: Date.now(),
        x: selectedElement.x + 20,
        y: selectedElement.y + 20
      };
      const newElements = [...elements, newElement];
      setElements(newElements);
      setSelectedElement(newElement);
      saveToHistory(newElements);
    }
  };

  // 更新元素样式
  const updateElementStyle = (property, value) => {
    if (selectedElement) {
      setElements(prev => prev.map(el => 
        el.id === selectedElement.id 
          ? { ...el, style: { ...el.style, [property]: value } }
          : el
      ));
      setSelectedElement(prev => ({ ...prev, style: { ...prev.style, [property]: value } }));
    }
  };

  // AI功能处理
  const handleAIFeature = (featureId) => {
    if (!selectedElement) {
      alert('请先选择一个元素');
      return;
    }

    switch (featureId) {
      case 'ai-style':
        // 模拟AI样式推荐
        const modernStyles = {
          fill: '#10b981',
          stroke: '#059669',
          strokeWidth: 3
        };
        setElements(prev => prev.map(el => 
          el.id === selectedElement.id 
            ? { ...el, style: { ...el.style, ...modernStyles } }
            : el
        ));
        setSelectedElement(prev => ({ ...prev, style: { ...prev.style, ...modernStyles } }));
        break;
      case 'ai-layout':
        // 模拟AI布局优化 - 自动对齐到网格
        const gridSize = 20;
        const alignedX = Math.round(selectedElement.x / gridSize) * gridSize;
        const alignedY = Math.round(selectedElement.y / gridSize) * gridSize;
        setElements(prev => prev.map(el => 
          el.id === selectedElement.id 
            ? { ...el, x: alignedX, y: alignedY }
            : el
        ));
        setSelectedElement(prev => ({ ...prev, x: alignedX, y: alignedY }));
        break;
      case 'ai-color':
        // 模拟AI配色建议
        const harmonicColors = ['#ef4444', '#f97316', '#eab308', '#22c55e', '#3b82f6', '#8b5cf6'];
        const randomColor = harmonicColors[Math.floor(Math.random() * harmonicColors.length)];
        updateElementStyle('fill', randomColor);
        break;
    }
    saveToHistory(elements);
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* 左侧工具栏 */}
      <div className="w-16 bg-white border-r border-gray-200 flex flex-col items-center py-4 space-y-2">
        {tools.map((tool) => {
          const Icon = tool.icon;
          return (
            <Button
              key={tool.id}
              variant={selectedTool === tool.id ? "default" : "ghost"}
              size="sm"
              className="w-10 h-10 p-0"
              onClick={() => setSelectedTool(tool.id)}
              title={tool.label}
            >
              <Icon className="w-4 h-4" />
            </Button>
          );
        })}
        
        <Separator className="w-8" />
        
        {/* AI功能按钮 */}
        {aiFeatures.map((feature) => {
          const Icon = feature.icon;
          return (
            <Button
              key={feature.id}
              variant="outline"
              size="sm"
              className="w-10 h-10 p-0 border-purple-200 text-purple-600 hover:bg-purple-50"
              onClick={() => handleAIFeature(feature.id)}
              title={feature.label}
            >
              <Icon className="w-4 h-4" />
            </Button>
          );
        })}
      </div>

      {/* 主编辑区域 */}
      <div className="flex-1 flex flex-col">
        {/* 顶部工具栏 */}
        <div className="h-12 bg-white border-b border-gray-200 flex items-center px-4 space-x-2">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={undo}
            disabled={historyIndex <= 0}
          >
            <Undo className="w-4 h-4 mr-1" />
            撤销
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={redo}
            disabled={historyIndex >= history.length - 1}
          >
            <Redo className="w-4 h-4 mr-1" />
            重做
          </Button>
          <Separator orientation="vertical" className="h-6" />
          <Button variant="ghost" size="sm" onClick={copySelectedElement} disabled={!selectedElement}>
            <Copy className="w-4 h-4 mr-1" />
            复制
          </Button>
          <Button variant="ghost" size="sm" onClick={deleteSelectedElement} disabled={!selectedElement}>
            <Trash2 className="w-4 h-4 mr-1" />
            删除
          </Button>
          <Separator orientation="vertical" className="h-6" />
          <Button variant="ghost" size="sm" onClick={() => setShowGrid(!showGrid)}>
            {showGrid ? <Eye className="w-4 h-4 mr-1" /> : <EyeOff className="w-4 h-4 mr-1" />}
            网格
          </Button>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" onClick={() => setZoom(Math.max(25, zoom - 25))}>
              <ZoomOut className="w-4 h-4" />
            </Button>
            <span className="text-sm w-12 text-center">{zoom}%</span>
            <Button variant="ghost" size="sm" onClick={() => setZoom(Math.min(200, zoom + 25))}>
              <ZoomIn className="w-4 h-4" />
            </Button>
          </div>
          <Separator orientation="vertical" className="h-6" />
          <Button variant="ghost" size="sm">
            <Save className="w-4 h-4 mr-1" />
            保存
          </Button>
          <Button variant="ghost" size="sm">
            <Download className="w-4 h-4 mr-1" />
            导出
          </Button>
        </div>

        {/* 画布区域 */}
        <div className="flex-1 overflow-auto p-4">
          <Card className="w-full h-full min-h-[600px] bg-white shadow-sm">
            <canvas
              ref={canvasRef}
              width={1000}
              height={700}
              className="w-full h-full cursor-crosshair"
              style={{ transform: `scale(${zoom / 100})`, transformOrigin: 'top left' }}
              onMouseDown={handleCanvasMouseDown}
              onMouseMove={handleCanvasMouseMove}
              onMouseUp={handleCanvasMouseUp}
            />
          </Card>
        </div>
      </div>

      {/* 右侧属性面板 */}
      <div className="w-80 bg-white border-l border-gray-200 p-4 overflow-y-auto">
        <h3 className="text-sm font-medium text-gray-900 mb-4">属性面板</h3>
        
        {selectedElement ? (
          <div className="space-y-6">
            {/* 基本信息 */}
            <div>
              <Label className="text-xs text-gray-500">元素类型</Label>
              <p className="text-sm font-medium capitalize">{selectedElement.type}</p>
            </div>

            {/* 位置和尺寸 */}
            <div className="space-y-3">
              <Label className="text-xs text-gray-500">位置和尺寸</Label>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-xs">X</Label>
                  <Input 
                    type="number" 
                    value={Math.round(selectedElement.x)} 
                    onChange={(e) => {
                      const newX = parseInt(e.target.value) || 0;
                      setElements(prev => prev.map(el => 
                        el.id === selectedElement.id ? { ...el, x: newX } : el
                      ));
                      setSelectedElement(prev => ({ ...prev, x: newX }));
                    }}
                    className="h-8 text-xs"
                  />
                </div>
                <div>
                  <Label className="text-xs">Y</Label>
                  <Input 
                    type="number" 
                    value={Math.round(selectedElement.y)} 
                    onChange={(e) => {
                      const newY = parseInt(e.target.value) || 0;
                      setElements(prev => prev.map(el => 
                        el.id === selectedElement.id ? { ...el, y: newY } : el
                      ));
                      setSelectedElement(prev => ({ ...prev, y: newY }));
                    }}
                    className="h-8 text-xs"
                  />
                </div>
                {selectedElement.width !== undefined && (
                  <>
                    <div>
                      <Label className="text-xs">宽度</Label>
                      <Input 
                        type="number" 
                        value={Math.round(selectedElement.width)} 
                        onChange={(e) => {
                          const newWidth = parseInt(e.target.value) || 0;
                          setElements(prev => prev.map(el => 
                            el.id === selectedElement.id ? { ...el, width: newWidth } : el
                          ));
                          setSelectedElement(prev => ({ ...prev, width: newWidth }));
                        }}
                        className="h-8 text-xs"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">高度</Label>
                      <Input 
                        type="number" 
                        value={Math.round(selectedElement.height)} 
                        onChange={(e) => {
                          const newHeight = parseInt(e.target.value) || 0;
                          setElements(prev => prev.map(el => 
                            el.id === selectedElement.id ? { ...el, height: newHeight } : el
                          ));
                          setSelectedElement(prev => ({ ...prev, height: newHeight }));
                        }}
                        className="h-8 text-xs"
                      />
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* 样式设置 */}
            {selectedElement.style && (
              <div className="space-y-3">
                <Label className="text-xs text-gray-500">样式</Label>
                
                {selectedElement.style.fill && (
                  <div>
                    <Label className="text-xs">填充颜色</Label>
                    <div className="flex items-center space-x-2">
                      <input 
                        type="color" 
                        value={selectedElement.style.fill}
                        onChange={(e) => updateElementStyle('fill', e.target.value)}
                        className="w-8 h-8 rounded border"
                      />
                      <Input 
                        value={selectedElement.style.fill}
                        onChange={(e) => updateElementStyle('fill', e.target.value)}
                        className="h-8 text-xs"
                      />
                    </div>
                  </div>
                )}

                {selectedElement.style.stroke && (
                  <div>
                    <Label className="text-xs">边框颜色</Label>
                    <div className="flex items-center space-x-2">
                      <input 
                        type="color" 
                        value={selectedElement.style.stroke}
                        onChange={(e) => updateElementStyle('stroke', e.target.value)}
                        className="w-8 h-8 rounded border"
                      />
                      <Input 
                        value={selectedElement.style.stroke}
                        onChange={(e) => updateElementStyle('stroke', e.target.value)}
                        className="h-8 text-xs"
                      />
                    </div>
                  </div>
                )}

                {selectedElement.style.strokeWidth && (
                  <div>
                    <Label className="text-xs">边框宽度: {selectedElement.style.strokeWidth}px</Label>
                    <Slider
                      value={[selectedElement.style.strokeWidth]}
                      onValueChange={([value]) => updateElementStyle('strokeWidth', value)}
                      max={10}
                      min={1}
                      step={1}
                      className="mt-2"
                    />
                  </div>
                )}

                {selectedElement.style.opacity !== undefined && (
                  <div>
                    <Label className="text-xs">透明度: {Math.round(selectedElement.style.opacity * 100)}%</Label>
                    <Slider
                      value={[selectedElement.style.opacity * 100]}
                      onValueChange={([value]) => updateElementStyle('opacity', value / 100)}
                      max={100}
                      min={0}
                      step={1}
                      className="mt-2"
                    />
                  </div>
                )}
              </div>
            )}

            {/* 文本特有属性 */}
            {selectedElement.type === 'text' && (
              <div className="space-y-3">
                <Label className="text-xs text-gray-500">文本属性</Label>
                <div>
                  <Label className="text-xs">内容</Label>
                  <Input 
                    value={selectedElement.content}
                    onChange={(e) => {
                      setElements(prev => prev.map(el => 
                        el.id === selectedElement.id ? { ...el, content: e.target.value } : el
                      ));
                      setSelectedElement(prev => ({ ...prev, content: e.target.value }));
                    }}
                    className="h-8 text-xs"
                  />
                </div>
                <div>
                  <Label className="text-xs">字体大小: {selectedElement.style.fontSize}px</Label>
                  <Slider
                    value={[selectedElement.style.fontSize]}
                    onValueChange={([value]) => updateElementStyle('fontSize', value)}
                    max={72}
                    min={8}
                    step={1}
                    className="mt-2"
                  />
                </div>
              </div>
            )}
          </div>
        ) : (
          <p className="text-sm text-gray-500">选择一个元素查看属性</p>
        )}

        <Separator className="my-6" />

        {/* 图层列表 */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-gray-900">图层</h4>
          <div className="space-y-1">
            {elements.map((element, index) => (
              <div 
                key={element.id}
                className={`p-2 rounded cursor-pointer text-xs flex items-center justify-between ${
                  selectedElement?.id === element.id ? 'bg-blue-50 border border-blue-200' : 'hover:bg-gray-50'
                }`}
                onClick={() => setSelectedElement(element)}
              >
                <span className="capitalize">{element.type} {index + 1}</span>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-6 w-6 p-0"
                  onClick={(e) => {
                    e.stopPropagation();
                    const newElements = elements.filter(el => el.id !== element.id);
                    setElements(newElements);
                    if (selectedElement?.id === element.id) {
                      setSelectedElement(null);
                    }
                    saveToHistory(newElements);
                  }}
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EnhancedDesignEditor;
