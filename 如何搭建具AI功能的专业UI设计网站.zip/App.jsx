import FinalApp from './components/FinalApp'
import './App.css'

function App() {
  return <FinalApp />
}

export default App
