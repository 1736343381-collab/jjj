import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Palette, 
  Sparkles, 
  Layers, 
  Wand2, 
  Zap, 
  ArrowRight,
  Play,
  CheckCircle,
  Users,
  Rocket,
  Brain
} from 'lucide-react';

const WelcomePage = ({ onGetStarted }) => {
  const [currentFeature, setCurrentFeature] = useState(0);

  const features = [
    {
      icon: Palette,
      title: '专业设计工具',
      description: '类似Sketch的矢量编辑、画板管理、组件库等核心功能',
      color: 'bg-blue-500'
    },
    {
      icon: Sparkles,
      title: 'AI智能助手',
      description: '一键修改局部设计稿，AI样式推荐和配色建议',
      color: 'bg-purple-500'
    },
    {
      icon: Layers,
      title: '实时协作',
      description: '多人同时编辑，版本历史管理，团队协作无缝衔接',
      color: 'bg-green-500'
    },
    {
      icon: Zap,
      title: '高效工作流',
      description: '智能布局优化，快速原型制作，提升设计效率',
      color: 'bg-orange-500'
    }
  ];

  const aiCapabilities = [
    {
      icon: Wand2,
      title: 'AI样式推荐',
      description: '基于设计趋势和最佳实践，为您的元素推荐现代化样式'
    },
    {
      icon: Brain,
      title: '智能配色',
      description: '自动生成和谐的配色方案，确保视觉一致性'
    },
    {
      icon: Layers,
      title: '布局优化',
      description: '智能调整元素对齐、间距，优化整体布局结构'
    },
    {
      icon: Zap,
      title: '自然语言交互',
      description: '通过简单的文字描述，让AI理解并执行您的设计意图'
    }
  ];

  const testimonials = [
    {
      name: '张设计师',
      role: 'UI/UX设计师',
      company: '某互联网公司',
      content: 'AI功能真的很强大，特别是一键样式优化，节省了我很多时间！',
      avatar: '👨‍💻'
    },
    {
      name: '李产品',
      role: '产品经理',
      company: '创业公司',
      content: '团队协作功能很棒，设计师和开发者可以实时沟通，效率提升明显。',
      avatar: '👩‍💼'
    },
    {
      name: '王前端',
      role: '前端工程师',
      company: '科技公司',
      content: '设计稿导出的代码质量很高，大大减少了我们的开发工作量。',
      avatar: '👨‍💻'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100">
      {/* 头部导航 */}
      <nav className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-600 rounded-lg flex items-center justify-center">
                <Palette className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">DesignCraft</span>
              <Badge variant="secondary" className="ml-2">Beta</Badge>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost">功能介绍</Button>
              <Button variant="ghost">定价</Button>
              <Button variant="outline">登录</Button>
              <Button onClick={onGetStarted}>
                开始设计
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* 主要内容 */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* 英雄区域 */}
        <section className="py-20 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl font-bold text-gray-900 mb-6">
              AI驱动的
              <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                UI设计工具
              </span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              专为UI设计师打造的智能设计平台，结合传统设计工具的强大功能与AI的创新能力，
              让设计更简单、更高效、更具创意。
            </p>
            <div className="flex justify-center space-x-4">
              <Button size="lg" onClick={onGetStarted} className="px-8 py-3">
                <Play className="w-5 h-5 mr-2" />
                立即体验
              </Button>
              <Button size="lg" variant="outline" className="px-8 py-3">
                观看演示
              </Button>
            </div>
          </div>
        </section>

        {/* 核心功能展示 */}
        <section className="py-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">核心功能</h2>
            <p className="text-lg text-gray-600">
              集成专业设计工具与AI智能助手，为您提供完整的设计解决方案
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card 
                  key={index} 
                  className="hover:shadow-lg transition-all duration-300 cursor-pointer transform hover:-translate-y-1"
                  onClick={() => setCurrentFeature(index)}
                >
                  <CardHeader className="text-center">
                    <div className={`w-12 h-12 ${feature.color} rounded-lg flex items-center justify-center mx-auto mb-4`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-lg">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 text-center">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>

        {/* AI功能详细介绍 */}
        <section className="py-16 bg-white rounded-2xl shadow-sm">
          <div className="px-8">
            <div className="text-center mb-12">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">AI智能功能</h2>
              <p className="text-lg text-gray-600">
                革命性的AI技术，让设计工作更智能、更高效
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {aiCapabilities.map((capability, index) => {
                const Icon = capability.icon;
                return (
                  <div key={index} className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Icon className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        {capability.title}
                      </h3>
                      <p className="text-gray-600">
                        {capability.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-12 text-center">
              <Button size="lg" onClick={onGetStarted} className="px-8 py-3">
                体验AI功能
                <Sparkles className="w-5 h-5 ml-2" />
              </Button>
            </div>
          </div>
        </section>

        {/* 用户评价 */}
        <section className="py-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">用户评价</h2>
            <p className="text-lg text-gray-600">
              看看其他设计师和开发者怎么说
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="text-2xl mr-3">{testimonial.avatar}</div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                      <p className="text-sm text-gray-600">{testimonial.role}</p>
                      <p className="text-xs text-gray-500">{testimonial.company}</p>
                    </div>
                  </div>
                  <p className="text-gray-700 italic">"{testimonial.content}"</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* 行动号召 */}
        <section className="py-20 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              准备好开始您的设计之旅了吗？
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              加入数千名设计师，体验AI驱动的设计工具带来的效率提升
            </p>
            <div className="flex justify-center space-x-4">
              <Button size="lg" onClick={onGetStarted} className="px-8 py-4 text-lg">
                <Rocket className="w-5 h-5 mr-2" />
                免费开始设计
              </Button>
              <Button size="lg" variant="outline" className="px-8 py-4 text-lg">
                <Users className="w-5 h-5 mr-2" />
                联系销售团队
              </Button>
            </div>
            <p className="text-sm text-gray-500 mt-4">
              无需信用卡 • 立即开始 • 随时取消
            </p>
          </div>
        </section>
      </main>

      {/* 页脚 */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-blue-600 rounded-lg flex items-center justify-center">
                  <Palette className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold">DesignCraft</span>
              </div>
              <p className="text-gray-400">
                AI驱动的UI设计工具，让设计更智能、更高效。
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">产品</h3>
              <ul className="space-y-2 text-gray-400">
                <li>设计工具</li>
                <li>AI功能</li>
                <li>协作平台</li>
                <li>API接口</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">支持</h3>
              <ul className="space-y-2 text-gray-400">
                <li>帮助中心</li>
                <li>教程文档</li>
                <li>社区论坛</li>
                <li>联系我们</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">公司</h3>
              <ul className="space-y-2 text-gray-400">
                <li>关于我们</li>
                <li>招聘信息</li>
                <li>隐私政策</li>
                <li>服务条款</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 DesignCraft. 保留所有权利。</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default WelcomePage;
